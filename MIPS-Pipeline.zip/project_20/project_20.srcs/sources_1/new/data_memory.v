`timescale 1ns / 1ps

module data_memory 
(
    input  wire        clk,
    input  wire        MemWrite,
    input  wire        MemRead,
    input  wire [31:0] addr,
    input  wire [31:0] write_data,
    output reg  [31:0] read_data
);
    reg [31:0] mem [0:255];
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1)
            mem[i] = 32'h00000000;
        $readmemb("data.mem", mem);
    end

    always @(posedge clk) begin
        if (MemWrite)
            mem[addr[31:2]] <= write_data;
    end

    always @(*) begin
        if (MemRead)
            read_data = mem[addr[31:2]];
        else
            read_data = 32'h00000000;
    end
endmodule

