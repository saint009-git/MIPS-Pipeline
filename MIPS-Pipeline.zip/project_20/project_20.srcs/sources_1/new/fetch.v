`timescale 1ns / 1ps

module fetch 
(
    input  wire        clk,
    input  wire        rst,
    input  wire        ex_mem_pc_src,
    input  wire [31:0] ex_mem_npc,
    output wire [31:0] if_id_instr,
    output wire [31:0] if_id_npc
);
    wire [31:0] pc_reg_out;
    wire [31:0] npc;
    wire [31:0] mux_out;
    wire [31:0] instr_data;

    pc pc0 
    (
        .clk(clk),
        .rst(rst),
        .pc_in(mux_out),
        .pc_out(pc_reg_out)
    );

    incrementer inc0 
    (
        .pcin(pc_reg_out),
        .pcout(npc)
    );

    mux32 pc_mux 
    (
        .a_true(ex_mem_npc),
        .b_false(npc),
        .sel(ex_mem_pc_src),
        .y(mux_out)
    );

    instrMem #
    (
        .ADDR_WIDTH(10)
    ) 
    inMem0 
    (
        .clk(clk),
        .rst(rst),
        .addr(pc_reg_out),
        .data(instr_data)
    );

    ifIdLatch ifId0 
    (
        .clk(clk),
        .rst(rst),
        .pc_in(npc),
        .instr_in(instr_data),
        .pc_out(if_id_npc),
        .instr_out(if_id_instr)
    );
endmodule
