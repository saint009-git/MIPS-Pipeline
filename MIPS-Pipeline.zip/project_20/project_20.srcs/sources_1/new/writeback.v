`timescale 1ns / 1ps

module writeback 
(
    input  wire [31:0] ReadData,
    input  wire [31:0] ALUResult,
    input  wire [4:0]  WriteReg_in,
    input  wire [1:0]  WBControl,
    output wire [31:0] WriteData,
    output wire [4:0]  WriteReg_out,
    output wire        RegWrite
);
    wire MemToReg = WBControl[0];
    wire RegWrite_bit = WBControl[1];

    assign WriteData    = MemToReg ? ReadData : ALUResult;
    assign WriteReg_out = WriteReg_in;
    assign RegWrite     = RegWrite_bit;
endmodule

