`timescale 1ns / 1ps

module mem_wb_latch 
(
    input  wire        clk,
    input  wire [31:0] ALUResult_in,
    input  wire [31:0] ReadData_in,
    input  wire [4:0]  WriteReg_in,
    input  wire [1:0]  WBControl_in,
    output reg [31:0] ALUResult_out,
    output reg [31:0] ReadData_out,
    output reg [4:0]  WriteReg_out,
    output reg [1:0]  WBControl_out
);
    initial begin
        ALUResult_out <= 0;
        ReadData_out  <= 0;
        WriteReg_out  <= 0;
        WBControl_out <= 0;
    end

    always @(posedge clk) begin
        ALUResult_out <= ALUResult_in;
        ReadData_out  <= ReadData_in;
        WriteReg_out  <= WriteReg_in;
        WBControl_out <= WBControl_in;
    end
endmodule

