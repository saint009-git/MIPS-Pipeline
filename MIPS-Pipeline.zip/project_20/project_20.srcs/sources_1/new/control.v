`timescale 1ns / 1ps

module control
(
    input  wire        clk,
    input  wire        rst,
    input  wire [5:0]  opcode,
    output reg  [1:0]  wb,
    output reg  [2:0]  mem,
    output reg  [3:0]  ex
);
    always @(*) begin
        if (rst) begin
            wb  = 0;
            mem = 0;
            ex  = 0;
        end else begin
            case (opcode)
                6'b000000: begin
                    wb  = 2'b10;
                    mem = 3'b000;
                    ex  = 4'b1010;
                end
                6'b100011: begin
                    wb  = 2'b11;
                    mem = 3'b010;
                    ex  = 4'b0010;
                end
                6'b101011: begin
                    wb  = 2'b00;
                    mem = 3'b001;
                    ex  = 4'b0010;
                end
                6'b000100: begin
                    wb  = 2'b00;
                    mem = 3'b100;
                    ex  = 4'b0101;
                end
                default: begin
                    wb  = 0;
                    mem = 0;
                    ex  = 0;
                end
            endcase
        end
    end
endmodule

