`timescale 1ns / 1ps

module mem_stage 
(
    input  wire        clk,
    input  wire [31:0] ALUResult,
    input  wire [31:0] WriteData,
    input  wire [4:0]  WriteReg,
    input  wire [1:0]  WBControl,
    input  wire        MemWrite,
    input  wire        MemRead,
    input  wire        Branch,
    input  wire        Zero,
    output wire [31:0] ReadData,
    output wire [31:0] ALUResult_out,
    output wire [4:0]  WriteReg_out,
    output wire [1:0]  WBControl_out,
    output wire        PCSrc
);
    wire pcsrc_int;
    wire [31:0] mem_read_data;
    wire [31:0] alu_latched;
    wire [31:0] read_latched;
    wire [4:0]  wreg_latched;
    wire [1:0]  wb_latched;

    and_gate u_and 
    (
        .a(Branch),
        .b(Zero),
        .y(pcsrc_int)
    );

    data_memory u_dmem 
    (
        .clk(clk),
        .MemWrite(MemWrite),
        .MemRead(MemRead),
        .addr(ALUResult),
        .write_data(WriteData),
        .read_data(mem_read_data)
    );

    mem_wb_latch u_memwb 
    (
        .clk(clk),
        .ALUResult_in(ALUResult),
        .ReadData_in(mem_read_data),
        .WriteReg_in(WriteReg),
        .WBControl_in(WBControl),
        .ALUResult_out(alu_latched),
        .ReadData_out(read_latched),
        .WriteReg_out(wreg_latched),
        .WBControl_out(wb_latched)
    );

    assign ReadData       = read_latched;
    assign ALUResult_out  = alu_latched;
    assign WriteReg_out   = wreg_latched;
    assign WBControl_out  = wb_latched;
    assign PCSrc          = pcsrc_int;
endmodule

