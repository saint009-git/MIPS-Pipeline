`timescale 1ns / 1ps

module mips_pipeline 
(
    input wire clk,
    input wire rst
);
    wire [31:0] if_id_instr;
    wire [31:0] if_id_npc;

    wire [1:0]  id_ex_wb;
    wire [2:0]  id_ex_mem;
    wire [3:0]  id_ex_ex;
    wire [31:0] id_ex_npc;
    wire [31:0] id_ex_readdat1;
    wire [31:0] id_ex_readdat2;
    wire [31:0] id_ex_sign_ext;
    wire [4:0]  id_ex_instr_bits_20_16;
    wire [4:0]  id_ex_instr_bits_15_11;
    wire [5:0]  id_ex_funct;

    wire [1:0]  ex_mem_wb_out;
    wire [2:0]  ex_mem_mem_out;
    wire [31:0] ex_mem_branch_target;
    wire        ex_mem_zero;
    wire [31:0] ex_mem_alu_result;
    wire [31:0] ex_mem_rdata2out;
    wire [4:0]  ex_mem_write_reg;

    wire [31:0] mem_ReadData;
    wire [31:0] mem_ALUResult_out;
    wire [4:0]  mem_WriteReg_out;
    wire [1:0]  mem_WBControl_out;
    wire        mem_PCSrc;

    wire [31:0] wb_WriteData;
    wire [4:0]  wb_WriteReg;
    wire        wb_RegWrite;

    fetch F0
    (
        .clk(clk),
        .rst(rst),
        .ex_mem_pc_src(mem_PCSrc),
        .ex_mem_npc(ex_mem_branch_target),
        .if_id_instr(if_id_instr),
        .if_id_npc(if_id_npc)
    );

    decode D0
    (
        .clk(clk),
        .rst(rst),
        .wb_reg_write(wb_RegWrite),
        .wb_write_reg_location(wb_WriteReg),
        .mem_wb_write_data(wb_WriteData),
        .if_id_instr(if_id_instr),
        .if_id_npc(if_id_npc),
        .id_ex_wb(id_ex_wb),
        .id_ex_mem(id_ex_mem),
        .id_ex_execute(id_ex_ex),
        .id_ex_npc(id_ex_npc),
        .id_ex_readdat1(id_ex_readdat1),
        .id_ex_readdat2(id_ex_readdat2),
        .id_ex_sign_ext(id_ex_sign_ext),
        .id_ex_instr_bits_20_16(id_ex_instr_bits_20_16),
        .id_ex_instr_bits_15_11(id_ex_instr_bits_15_11),
        .id_ex_funct(id_ex_funct)
    );

    execute E0
    (
        .clk(clk),
        .rst(rst),
        .id_ex_wb(id_ex_wb),
        .id_ex_mem(id_ex_mem),
        .id_ex_ex(id_ex_ex),
        .id_ex_npc(id_ex_npc),
        .id_ex_readdat1(id_ex_readdat1),
        .id_ex_readdat2(id_ex_readdat2),
        .id_ex_sign_ext(id_ex_sign_ext),
        .id_ex_instr_bits_20_16(id_ex_instr_bits_20_16),
        .id_ex_instr_bits_15_11(id_ex_instr_bits_15_11),
        .id_ex_funct(id_ex_funct),
        .ex_mem_wb_out(ex_mem_wb_out),
        .ex_mem_mem_out(ex_mem_mem_out),
        .ex_mem_branch_target(ex_mem_branch_target),
        .ex_mem_zero(ex_mem_zero),
        .ex_mem_alu_result(ex_mem_alu_result),
        .ex_mem_rdata2out(ex_mem_rdata2out),
        .ex_mem_write_reg(ex_mem_write_reg)
    );

    mem_stage M0
    (
        .clk(clk),
        .ALUResult(ex_mem_alu_result),
        .WriteData(ex_mem_rdata2out),
        .WriteReg(ex_mem_write_reg),
        .WBControl(ex_mem_wb_out),
        .MemWrite(ex_mem_mem_out[0]),
        .MemRead(ex_mem_mem_out[1]),
        .Branch(ex_mem_mem_out[2]),
        .Zero(ex_mem_zero),
        .ReadData(mem_ReadData),
        .ALUResult_out(mem_ALUResult_out),
        .WriteReg_out(mem_WriteReg_out),
        .WBControl_out(mem_WBControl_out),
        .PCSrc(mem_PCSrc)
    );

    writeback WB0
    (
        .ReadData(mem_ReadData),
        .ALUResult(mem_ALUResult_out),
        .WriteReg_in(mem_WriteReg_out),
        .WBControl(mem_WBControl_out),
        .WriteData(wb_WriteData),
        .WriteReg_out(wb_WriteReg),
        .RegWrite(wb_RegWrite)
    );
endmodule

