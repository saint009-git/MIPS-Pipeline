`timescale 1ns / 1ps

module instrMem #
(
    parameter ADDR_WIDTH = 10,
    parameter DEPTH      = (1 << ADDR_WIDTH)
) 
(
    input  wire         clk,
    input  wire         rst,
    input  wire [31:0]  addr,
    output reg  [31:0]  data
);
    reg [31:0] mem [0:DEPTH-1];
    integer i;

    initial begin
        for (i = 0; i < DEPTH; i = i + 1)
            mem[i] = 32'h00000000;
        $readmemb("instr.mem", mem);
    end

    wire [ADDR_WIDTH-1:0] index;
    wire [31:0] safe_index_ext;
    assign safe_index_ext = addr[31:2];
    assign index = safe_index_ext[ADDR_WIDTH-1:0];

    always @(*) begin
        if (rst) begin
            data = 32'h00000000;
        end else begin
            if (safe_index_ext >= DEPTH)
                data = 32'h00000000;
            else
                data = mem[index];
        end
    end
endmodule
