`timescale 1ns / 1ps

module ex_mem
(
    input wire        clk,
    input wire [1:0]  ctlwb_in,
    input wire [2:0]  ctlm_in,
    input wire [31:0] adder_in,
    input wire        aluzero_in,
    input wire [31:0] alu_in,
    input wire [31:0] readdat2_in,
    input wire [4:0]  mux_in,
    output reg [1:0]  wb_ctlout,
    output reg        branch,
    output reg        memread,
    output reg        memwrite,
    output reg [31:0] add_result,
    output reg        zero,
    output reg [31:0] alu_result,
    output reg [31:0] rdata2out,
    output reg [4:0]  five_bit_muxout
);
    initial begin
        wb_ctlout       <= 0;
        branch          <= 0;
        memread         <= 0;
        memwrite        <= 0;
        add_result      <= 0;
        zero            <= 0;
        alu_result      <= 0;
        rdata2out       <= 0;
        five_bit_muxout <= 0;
    end

    always @(posedge clk) begin
        wb_ctlout       <= ctlwb_in;
        branch          <= ctlm_in[2];
        memread         <= ctlm_in[1];
        memwrite        <= ctlm_in[0];
        add_result      <= adder_in;
        zero            <= aluzero_in;
        alu_result      <= alu_in;
        rdata2out       <= readdat2_in;
        five_bit_muxout <= mux_in;
    end
endmodule

