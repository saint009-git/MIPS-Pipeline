`timescale 1ns / 1ps

module execute
(
    input  wire        clk,
    input  wire        rst,
    input  wire [1:0]  id_ex_wb,
    input  wire [2:0]  id_ex_mem,
    input  wire [3:0]  id_ex_ex,
    input  wire [31:0] id_ex_npc,
    input  wire [31:0] id_ex_readdat1,
    input  wire [31:0] id_ex_readdat2,
    input  wire [31:0] id_ex_sign_ext,
    input  wire [4:0]  id_ex_instr_bits_20_16,
    input  wire [4:0]  id_ex_instr_bits_15_11,
    input  wire [5:0]  id_ex_funct,
    output wire [1:0]  ex_mem_wb_out,
    output wire [2:0]  ex_mem_mem_out,
    output wire [31:0] ex_mem_branch_target,
    output wire        ex_mem_zero,
    output wire [31:0] ex_mem_alu_result,
    output wire [31:0] ex_mem_rdata2out,
    output wire [4:0]  ex_mem_write_reg
);
    wire regdst = id_ex_ex[3];
    wire alusrc = id_ex_ex[2];
    wire [1:0] aluop = id_ex_ex[1:0];

    wire [31:0] branch_addr;
    wire [4:0]  muxout;
    wire [2:0]  alu_ctrl;
    wire [31:0] alu_b;
    wire [31:0] aluout;
    wire        aluzero;

    wire [1:0]  wb_ctlout_latch;
    wire        branch_latch;
    wire        memread_latch;
    wire        memwrite_latch;
    wire [31:0] ex_mem_npc;
    wire        zero_latch;
    wire [31:0] alu_result_latch;
    wire [31:0] rdata2_latch;
    wire [4:0]  five_bit_muxout_latch;

    wire [2:0] m_ctl_full = id_ex_mem;

    adder adder3
    (
        .add_in1(id_ex_npc),
        .add_in2(id_ex_sign_ext),
        .add_out(branch_addr)
    );

    bottom_mux bottom_mux3
    (
        .a(id_ex_instr_bits_15_11),
        .b(id_ex_instr_bits_20_16),
        .sel(regdst),
        .y(muxout)
    );

    alu_control alu_control3
    (
        .funct(id_ex_funct),
        .aluop(aluop),
        .select(alu_ctrl)
    );

    top_mux top_mux3
    (
        .y(alu_b),
        .a(id_ex_sign_ext),
        .b(id_ex_readdat2),
        .alusrc(alusrc)
    );

    alu alu3
    (
        .a(id_ex_readdat1),
        .b(alu_b),
        .control(alu_ctrl),
        .result(aluout),
        .zero(aluzero)
    );

    ex_mem ex_mem3
    (
        .clk(clk),
        .ctlwb_in(id_ex_wb),
        .ctlm_in(m_ctl_full),
        .adder_in(branch_addr),
        .aluzero_in(aluzero),
        .alu_in(aluout),
        .readdat2_in(id_ex_readdat2),
        .mux_in(muxout),
        .wb_ctlout(wb_ctlout_latch),
        .branch(branch_latch),
        .memread(memread_latch),
        .memwrite(memwrite_latch),
        .add_result(ex_mem_npc),
        .zero(zero_latch),
        .alu_result(alu_result_latch),
        .rdata2out(rdata2_latch),
        .five_bit_muxout(five_bit_muxout_latch)
    );

    assign ex_mem_wb_out        = wb_ctlout_latch;
    assign ex_mem_mem_out       = {branch_latch, memread_latch, memwrite_latch};
    assign ex_mem_branch_target = ex_mem_npc;
    assign ex_mem_zero          = zero_latch;
    assign ex_mem_alu_result    = alu_result_latch;
    assign ex_mem_rdata2out     = rdata2_latch;
    assign ex_mem_write_reg     = five_bit_muxout_latch;
endmodule
